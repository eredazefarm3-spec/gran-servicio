import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
const FROM = Deno.env.get("RESEND_FROM_EMAIL") || "Gran Servicio <no-reply@granservicio.com>";
const json=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{"Content-Type":"application/json"}});
const esc=(v:unknown)=>String(v??"").replace(/[&<>\"]/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]!));

Deno.serve(async(req)=>{
  if(req.method!=="POST") return json({error:"Método no permitido."},405);
  if(!RESEND_API_KEY) return json({error:"Falta configurar RESEND_API_KEY para enviar correos."},503);
  const authorization=req.headers.get("Authorization");
  if(!authorization) return json({error:"Sesión requerida."},401);
  const userClient=createClient(SUPABASE_URL,ANON,{global:{headers:{Authorization:authorization}}});
  const {data:{user},error:userError}=await userClient.auth.getUser();
  if(userError||!user) return json({error:"Sesión inválida."},401);
  const admin=createClient(SUPABASE_URL,SERVICE_ROLE);
  const {data:empleado}=await admin.from("usuario_empleado").select("id_empleado").eq("id_auth",user.id).eq("activo",true).maybeSingle();
  if(!empleado) return json({error:"No autorizado."},403);
  try{
    const body=await req.json();
    const APP_URL=(Deno.env.get("APP_URL") || req.headers.get("origin") || "").replace(/\/$/,"");
    const id=Number(body?.id_profesional);
    const estado=String(body?.estado||"");
    const tipo=String(body?.tipo||"profesional");
    if(!Number.isInteger(id)||id<=0) return json({error:"Profesional inválido."},400);
    if(!["aprobado","rechazado"].includes(estado)) return json({error:"Estado inválido."},400);
    const {data:p}=await admin.from("usuario_profesional").select("id_profesional,nombre,apellido,email,id_rubro,rubros(nombre)").eq("id_profesional",id).single();
    if(!p) return json({error:"Profesional no encontrado."},404);
    let subject="",title="",message="",extra="";
    if(tipo==="servicio"){
      const sid=Number(body?.id_servicio); if(!Number.isInteger(sid)||sid<=0) return json({error:"Servicio inválido."},400);
      const {data:s}=await admin.from("servicios").select("id_servicio,nombre").eq("id_servicio",sid).single();
      const serviceName=s?.nombre||"nuevo servicio";
      if(estado==="aprobado"){
        subject=`Gran Servicio — título aprobado: ${serviceName}`; title="¡Tu nuevo título fue aprobado!"; message=`Ya podés ofrecer <strong>${esc(serviceName)}</strong> desde tu perfil de Gran Servicio.`;
      }else{
        subject=`Gran Servicio — título rechazado: ${serviceName}`; title="Tu título necesita correcciones"; message=`La solicitud para ofrecer <strong>${esc(serviceName)}</strong> fue rechazada.`; extra=`<div style="margin-top:18px;padding:14px;border-radius:10px;background:#fff3f2;border:1px solid #f0b7b0"><strong>Motivo:</strong><br>${esc(body?.motivo||"No especificado")}</div>`;
      }
    }else{
      if(estado==="aprobado"){
        subject="Gran Servicio — ¡tu solicitud fue aprobada!"; title="¡Ya sos profesional aprobado!"; message=`Hola <strong>${esc(p.nombre)}</strong>, tu solicitud profesional fue aprobada. Ya podés ingresar y comenzar a ofrecer tus servicios.`; extra=`<div style="margin-top:18px;padding:14px;border-radius:10px;background:#eefaf3;border:1px solid #a9dfbf"><strong>Rubro aprobado:</strong> ${esc(p.rubros?.nombre||"Profesional")}</div>`;
      }else{
        subject="Gran Servicio — tu solicitud necesita correcciones"; title="Tu solicitud necesita correcciones"; message=`Hola <strong>${esc(p.nombre)}</strong>, administración revisó tu solicitud profesional y no pudo aprobarla en esta instancia.`; extra=`<div style="margin-top:18px;padding:14px;border-radius:10px;background:#fff3f2;border:1px solid #f0b7b0"><strong>Motivo:</strong><br>${esc(body?.motivo||"No especificado")}</div><p style="margin-top:18px">Podés volver a presentar la documentación corregida desde Gran Servicio.</p>`;
      }
    }
    const html=`<!doctype html><html><body style="margin:0;background:#eef4f8;font-family:Arial,sans-serif;color:#17324d"><div style="max-width:620px;margin:30px auto;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 8px 30px #0b2e4f18"><div style="background:#0b2e4f;padding:24px;text-align:center"><div style="font-size:26px;font-weight:800;color:#fff">GRAN <span style="color:#ff8b1a">SERVICIO</span></div></div><div style="padding:32px"><div style="font-size:28px;margin-bottom:12px">${estado==="aprobado"?"🎉":"⚠️"}</div><h1 style="margin:0 0 12px;color:#0b2e4f">${title}</h1><p style="font-size:16px;line-height:1.6">${message}</p>${extra}<p style="margin-top:26px;line-height:1.6">Ingresá a Gran Servicio para continuar con tu cuenta.</p><div style="margin-top:24px;text-align:center"><a href="${esc(APP_URL || "#")}" style="display:inline-block;background:#ff8b1a;color:#fff;text-decoration:none;padding:13px 22px;border-radius:9px;font-weight:700">Ir a Gran Servicio</a></div></div><div style="padding:18px 32px;background:#f4f7fa;color:#6b7e90;font-size:12px">Este correo fue enviado automáticamente por Gran Servicio.</div></div></body></html>`;
    const send=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${RESEND_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({from:FROM,to:[p.email],subject,html})});
    const data=await send.json();
    if(!send.ok) return json({error:"El cambio se aplicó, pero el correo no pudo enviarse.",detail:data},502);
    return json({ok:true,email:p.email,id:data.id});
  }catch(e){return json({error:"No se pudo preparar el correo.",detail:String(e)},500);}
});
