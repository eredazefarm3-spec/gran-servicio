import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const MP_TOKEN=Deno.env.get("MERCADOPAGO_ACCESS_TOKEN");
const URL=Deno.env.get("SUPABASE_URL")!;
const ANON=Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE_ROLE=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const CORS={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST,OPTIONS"}; const json=(b:unknown,s=200)=>new Response(JSON.stringify(b),{status:s,headers:{"Content-Type":"application/json",...CORS}});

Deno.serve(async(req)=>{
  if(req.method==="OPTIONS") return new Response("ok",{status:204,headers:CORS});
  if(req.method!=="POST") return json({error:"Método no permitido."},405);
  if(!MP_TOKEN||!SERVICE_ROLE) return json({error:"Mercado Pago no está configurado."},503);
  const auth=req.headers.get("Authorization"); if(!auth) return json({error:"Sesión requerida."},401);
  const client=createClient(URL,ANON,{global:{headers:{Authorization:auth}}});
  const {data:{user}}=await client.auth.getUser(); if(!user) return json({error:"Sesión inválida."},401);
  const {data:e,error:roleError}=await client.from("usuario_empleado").select("id_empleado,id_rol,activo,roles(id_rol,nombre)").eq("id_auth",user.id).eq("activo",true).maybeSingle();
  if(roleError) return json({error:"No se pudo comprobar el rol."},500);
  const roleName=String(e?.roles?.nombre||"").trim().toLowerCase();
  if(!e||!["administrador","finanzas"].includes(roleName)) return json({error:"No tenés permisos para reembolsar."},403);

  const admin=createClient(URL,SERVICE_ROLE);
  try{
    const b=await req.json();
    const id=Number(b?.id_pago);
    if(!Number.isInteger(id)||id<=0) return json({error:"Pago inválido."},400);
    const {data:pago,error:pagoError}=await admin.from("pagos").select("*,transacciones(*)").eq("id_pago",id).single();
    if(pagoError||!pago) return json({error:"Pago no encontrado."},404);
    if(!pago.mercado_pago_payment_id) return json({error:"El pago no tiene payment_id de Mercado Pago."},400);
    if(pago.reembolso_estado==="approved") return json({error:"El pago ya fue reembolsado."},409);
    if(pago.mercado_pago_status!=="approved") return json({error:"Solo se pueden reembolsar pagos aprobados."},400);

    const amount=b?.amount==null?null:Number(b.amount);
    if(amount!==null&&(!Number.isFinite(amount)||amount<=0||amount>Number(pago.monto))) return json({error:"Monto de reembolso inválido."},400);

    const refundKey=`gs-refund-${id}-${amount===null?"full":amount.toFixed(2)}`;
    const r=await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(String(pago.mercado_pago_payment_id))}/refunds`,{
      method:"POST",
      headers:{"Content-Type":"application/json",Authorization:`Bearer ${MP_TOKEN}`,"X-Idempotency-Key":refundKey},
      body:amount===null?"{}":JSON.stringify({amount})
    });
    const data=await r.json();
    if(!r.ok) return json({error:"Mercado Pago rechazó el reembolso."},r.status);

    const refundAmount=Number(data.amount??pago.monto);
    const {data:estadoPago}=await admin.from("estados").select("id_estado").eq("tipo_entidad","pago").ilike("nombre","Reembolsado").maybeSingle();
    const {data:estadoTx}=await admin.from("estados").select("id_estado").eq("tipo_entidad","transaccion").ilike("nombre","Reembolsada").maybeSingle();
    const {error:updateError}=await admin.from("pagos").update({
      reembolsado_en:new Date().toISOString(),reembolso_monto:refundAmount,reembolso_estado:"approved",
      mercado_pago_status:"refunded",id_estado:estadoPago?.id_estado??pago.id_estado
    }).eq("id_pago",id);
    if(updateError) return json({error:"El reembolso se realizó, pero no pudimos actualizar el registro local."},500);
    if(pago.transacciones?.id_transaccion&&estadoTx?.id_estado&&refundAmount>=Number(pago.monto)){
      await admin.from("transacciones").update({id_estado:estadoTx.id_estado}).eq("id_transaccion",pago.transacciones.id_transaccion);
    }
    if(pago.transacciones?.tipo_transaccion==="suscripcion"&&pago.transacciones?.id_profesional&&pago.transacciones?.id_plan){
      const {data:cancel}=await admin.from("estados").select("id_estado").eq("tipo_entidad","suscripcion").ilike("nombre","Cancelada").maybeSingle();
      if(cancel?.id_estado) await admin.from("suscriptores").update({id_estado:cancel.id_estado}).eq("id_profesional",pago.transacciones.id_profesional).eq("id_plan",pago.transacciones.id_plan).eq("id_estado",(await admin.from("estados").select("id_estado").eq("tipo_entidad","suscripcion").ilike("nombre","Activa").maybeSingle()).data?.id_estado);
    }
    return json({ok:true,refund:data});
  }catch{return json({error:"No se pudo procesar el reembolso."},500)}
});